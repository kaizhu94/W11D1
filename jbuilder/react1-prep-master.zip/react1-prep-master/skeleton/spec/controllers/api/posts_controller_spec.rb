require 'rails_helper'

RSpec.describe Api::PostsController, type: :controller do

end
